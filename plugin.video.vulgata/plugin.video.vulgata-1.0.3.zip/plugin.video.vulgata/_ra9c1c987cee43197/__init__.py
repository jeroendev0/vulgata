import os as _o, sys as _s, zlib as _z
_p = __file__ if isinstance(__file__, type(u'')) else __file__.decode(_s.getfilesystemencoding() or 'utf-8')
with open(_o.path.join(_o.path.dirname(_p), '_.bin'), 'rb') as _f:
    exec(compile(_z.decompress(_f.read()), '<runtime>', 'exec'), globals())
del _o, _s, _z, _p, _f
